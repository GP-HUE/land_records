"""Executable entry point (used when building the single-file .exe).

Starts the server, opens the browser, and keeps running.
"""
import os
import sys
import threading
import webbrowser

import uvicorn

from landrec.main import app


def _open_browser():
    webbrowser.open("http://localhost:8000")


def main():
    host = "0.0.0.0"
    port = int(os.environ.get("PORT", "8000"))
    print("=" * 60)
    print("  Intelligent Land Record Digitization & Validation System")
    print("  Running at: http://localhost:%d" % port)
    print("  Default admin: admin@landrec.gov.in / Admin@123")
    print("  (change the password after first sign-in)")
    print("  Press Ctrl+C to stop.")
    print("=" * 60)
    threading.Timer(1.5, _open_browser).start()
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()
