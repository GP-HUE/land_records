"""Field extraction: map OCR text to structured land-record fields with confidence."""
import re

from . import common

# words that appear right after a label but are not the actual value
JUNK_WORDS = {
    "no", "no.", "number", "num", "नंबर", "नं.", "संख्या", "क्र.", "क्र",
    "सं.", "नाम", "का", "name", ":", "=", "-",
}

# fields whose value must contain a digit
NUMERIC_FIELDS = {"survey_number", "khasra_number", "khata_number", "plot_number",
                  "mutation_no", "registration_no", "khatauni_year"}

# characters that signal OCR failure / uncertainty
GARBAGE_CHARS = "?॥|@#$%^&*[]{}"

DEVA_RANGE = (0x0900, 0x097F)


def _has_devanagari(s: str) -> bool:
    return any(DEVA_RANGE[0] <= ord(c) <= DEVA_RANGE[1] for c in s)


def _clean_value(raw: str) -> str:
    raw = raw.replace("|", " ").strip()
    raw = re.sub(r"\s+", " ", raw)
    return raw.strip(" .,-—–:;").strip()


def _strip_junk(value: str) -> str:
    """Remove leading junk words like 'नंबर:' / 'number' from an extracted value."""
    tokens = value.split()
    while tokens and tokens[0].strip(".:-—= ") .lower() in JUNK_WORDS:
        tokens.pop(0)
    return " ".join(tokens).strip(" :.-—–")


def _label_regex(label: str) -> re.Pattern:
    return re.compile(r"(?<!\w)" + re.escape(label) + r"(?!\w)", re.IGNORECASE)


def _lev(a: str, b: str) -> int:
    """Levenshtein edit distance between two strings."""
    a, b = a.lower(), b.lower()
    if abs(len(a) - len(b)) > 2:
        return 99
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[-1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def _fuzzy_token(tok: str, field_id: str) -> bool:
    """True if token is a small OCR-typo of any label's first word.
    Requires same length, same first char, and <=2 edits (1 for short words)."""
    t = tok.strip(" :.,").lower()
    if len(t) < 3:
        return False
    for lbl in common.LABEL_PATTERNS[field_id]:
        first = lbl.split()[0].lower()
        if len(first) < 3 or len(first) != len(t) or first[0] != t[0]:
            continue
        maxd = 1 if len(t) <= 4 else 2
        if _lev(t, first) <= maxd:
            return True
    return False


def _find_value(text: str, field_id: str):
    """Find label, return (remainder, quality). quality reflects match confidence."""
    lines = [l for l in text.splitlines()]
    # ---- pass 1: exact label match ----
    best = (None, 0.0)
    for i, line in enumerate(lines):
        for lbl in common.LABEL_PATTERNS[field_id]:
            lbl_n = common.normalize_numerals(lbl)
            m = _label_regex(lbl_n).search(line)
            if not m:
                continue
            remainder = line[m.end():]
            if not remainder.strip():
                remainder = lines[i + 1] if i + 1 < len(lines) else ""
            remainder = _clean_value(remainder)
            if not remainder:
                continue
            quality = 0.9  # same-line exact label match
            if quality > best[1]:
                best = (remainder, quality)
    if best[0]:
        return best

    # ---- pass 2: fuzzy label match (handles OCR typos like 'Matation' -> 'mutation') ----
    for i, line in enumerate(lines):
        tokens = line.split()
        for j, tok in enumerate(tokens):
            if _fuzzy_token(tok, field_id):
                remainder = _clean_value(" ".join(tokens[j + 1:]))
                if remainder:
                    return remainder, 0.72
    return None, 0.0


def extract_area(text: str):
    """Extract area value + unit."""
    lines = [l for l in text.splitlines() if l.strip()]
    for i, line in enumerate(lines):
        exact = any(_label_regex(lbl).search(line) for lbl in common.LABEL_PATTERNS["area"])
        fuzzy = any(_fuzzy_token(t, "area") for t in line.split())
        if not (exact or fuzzy):
            continue
        for cand in [line, lines[i + 1] if i + 1 < len(lines) else ""]:
            c = common.normalize_numerals(cand)
            m = re.search(r"(\d+(?:\.\d+)?)\s*(hectare|hect|ha|acre|ac|bigha|gunta|"
                          r"sq\.?\s*(?:ft|m)|sqft|sqm|sft|square\s*(?:feet|meter|metre)|"
                          r"वर्ग\s*(?:फुट|फीट|मीटर)|हेक्टेयर|हेक्टर|एकड़|एकड|बीघा|गुंठा|गुंठे)",
                          c, re.IGNORECASE)
            if m:
                value = float(m.group(1))
                unit_raw = m.group(2).lower()
                unit = "hectare"
                for uname, synonyms in common.AREA_UNITS.items():
                    if any(s in unit_raw for s in synonyms):
                        unit = uname
                        break
                return {"value": value, "unit": unit,
                        "display": f"{value:g} {unit.replace('_', ' ')}"}
    return None


def extract_class(text: str, kind: str) -> str:
    lowered = text.lower()
    vocab = common.LAND_CLASSES if kind == "land" else common.OWNERSHIP_TYPES
    for canonical, synonyms in vocab:
        if any(_label_regex(s).search(lowered) for s in synonyms):
            return canonical
    return None


def _value_word_conf(value: str, ocr_result: dict) -> float:
    """Mean tesseract word-confidence of the words overlapping the extracted value."""
    val_norm = common.normalize_numerals(value).lower().strip()
    if not val_norm:
        return 0.0
    confs = []
    for page in ocr_result["pages"]:
        for w, c in zip(page["words"], page["conf"]):
            wn = common.normalize_numerals(w).lower().strip()
            if not wn:
                continue
            if wn in val_norm or val_norm in wn:
                confs.append(c)
    if not confs:
        return 0.0
    return sum(confs) / len(confs) / 100.0


def extract_fields(ocr_result: dict) -> dict:
    text = ocr_result["full_text"]
    mean_ocr_conf = ocr_result["mean_conf"] / 100.0
    fields = {}

    for fid, _display, _labels in common.FIELD_DEFS:
        remainder, quality = _find_value(text, fid)
        if not remainder:
            continue
        value = _strip_junk(remainder)
        if not value:
            continue

        if fid in NUMERIC_FIELDS:
            m = re.search(r"[^\s]*\d[^\s]*", value)
            if not m:
                fields[fid] = {"value": value, "quality": quality * 0.4, "digits": ""}
                continue
            token = common.normalize_numerals(m.group(0)).strip(" :.,;—-")
            fields[fid] = {"value": token, "quality": quality,
                           "digits": common.digits_only(token)}
        else:
            value = re.split(r"\s{2,}", value)[0]
            fields[fid] = {"value": value, "quality": quality}

    area = extract_area(text)
    if area:
        fields["area"] = {"value": area["display"], "quality": 0.8,
                          "num_value": area["value"], "unit": area["unit"]}

    lc = extract_class(text, "land")
    if lc:
        fields["land_class"] = {"value": lc, "quality": 0.8}
    ot = extract_class(text, "ownership")
    if ot:
        fields["ownership_type"] = {"value": ot, "quality": 0.8}

    # Per-field confidence = word-OCR-conf (60%) + match quality (40%)
    for fid, f in fields.items():
        wc = _value_word_conf(f["value"], ocr_result)
        base = f.get("quality", 0.5)
        conf = 0.6 * wc + 0.4 * base
        # garbage characters => strong uncertainty
        if any(g in f["value"] for g in GARBAGE_CHARS):
            conf = min(conf, 0.55)
        # fall back to document mean when no word overlap found
        if wc == 0.0:
            conf = 0.5 * mean_ocr_conf + 0.5 * base
        f["confidence"] = round(min(0.99, conf), 3)

    return fields
