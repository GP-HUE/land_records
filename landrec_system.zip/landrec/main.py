"""FastAPI application: Intelligent Land Record Digitization & Validation System.

Multi-user with signup/sign-in, role-based access control, document upload,
verification workflow, learning loop, dashboards, and audit trail.
"""
import json
import os
import uuid

from fastapi import Depends, FastAPI, File, Header, HTTPException, Request, Response, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import auth, common, extractor, ocr, paths, store, validator

PKG = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(paths.resource_dir(), "landrec", "static")
SAMPLES_DIR = os.path.join(paths.resource_dir(), "samples")

SESSION_COOKIE = "lr_session"

app = FastAPI(title="Intelligent Land Record Digitization & Validation System")
store.init_db()


def _set_session_cookie(response: Response, token: str):
    # HttpOnly keeps the token out of reach of JS; SameSite=Lax mitigates CSRF.
    # secure=False so it works over plain HTTP (local) as well as HTTPS (proxied).
    response.set_cookie(SESSION_COOKIE, token, httponly=True, samesite="lax",
                        max_age=auth.TOKEN_TTL, path="/", secure=False)


def _clear_session_cookie(response: Response):
    response.delete_cookie(SESSION_COOKIE, path="/")


# --------------------------------------------------------------------------
# Auth dependencies
# --------------------------------------------------------------------------
def get_current_user(request: Request, authorization: str = Header(None)) -> dict:
    # Accept the session token through any of three channels, since reverse
    # proxies / sandboxed iframes may drop cookies or custom headers:
    #   1. session cookie (HttpOnly)
    #   2. Authorization: Bearer header
    #   3. ?token= query parameter (most resilient across proxies)
    token = request.cookies.get(SESSION_COOKIE)
    if not token and authorization and authorization.startswith("Bearer "):
        token = authorization[7:]
    if not token:
        token = request.query_params.get("token")
    if not token:
        raise HTTPException(401, "Not authenticated")
    payload = auth.verify_token(token)
    if not payload:
        raise HTTPException(401, "Invalid or expired session — please sign in again")
    user = store.get_user(payload["uid"])
    if (not user or not user["is_active"]
            or user["token_version"] != payload["ver"]):
        raise HTTPException(401, "Invalid session")
    return user


def require_role(min_role: str):
    def dep(user: dict = Depends(get_current_user)) -> dict:
        if auth.ROLE_LEVELS[user["role"]] < auth.ROLE_LEVELS[min_role]:
            raise HTTPException(403, "Insufficient permissions for this action")
        return user
    return dep


def _public_user(user: dict) -> dict:
    return {k: user[k] for k in ("id", "email", "full_name", "role", "created_at")}


# --------------------------------------------------------------------------
# Authentication endpoints
# --------------------------------------------------------------------------
@app.post("/api/auth/signup")
def signup(payload: dict, response: Response):
    try:
        uid = store.create_user(payload.get("email", ""), payload.get("password", ""),
                                payload.get("full_name", ""), role="operator")
    except ValueError as e:
        raise HTTPException(400, str(e))
    user = store.get_user(uid)
    token = auth.create_token(user["id"], user["role"], user["token_version"])
    _set_session_cookie(response, token)
    store.audit(None, user["id"], user["email"], "signup", user["email"])
    return {"token": token, "user": _public_user(user)}


@app.post("/api/auth/login")
def login(payload: dict, response: Response):
    email = (payload.get("email") or "").strip().lower()
    password = payload.get("password") or ""
    if store.login_locked(email):
        raise HTTPException(429, "Too many failed attempts. Try again in a few minutes.")
    user = store.get_user_by_email(email)
    if not user or not auth.verify_password(password, user["salt"], user["password_hash"]):
        store.record_login_failure(email)
        raise HTTPException(401, "Invalid email or password")
    if not user["is_active"]:
        raise HTTPException(403, "Account is deactivated. Contact an administrator.")
    store.clear_login_failures(email)
    token = auth.create_token(user["id"], user["role"], user["token_version"])
    _set_session_cookie(response, token)
    store.audit(None, user["id"], user["email"], "login", "")
    return {"token": token, "user": _public_user(user)}


@app.get("/api/auth/me")
def me(user: dict = Depends(get_current_user)):
    return {"user": _public_user(user)}


@app.post("/api/auth/logout")
def logout(response: Response, user: dict = Depends(get_current_user)):
    store.bump_token_version(user["id"])
    store.audit(None, user["id"], user["email"], "logout", "")
    _clear_session_cookie(response)
    return {"ok": True}


@app.post("/api/auth/change-password")
def change_password(payload: dict, user: dict = Depends(get_current_user)):
    current = payload.get("current_password", "")
    new = payload.get("new_password", "")
    if not auth.verify_password(current, user["salt"], user["password_hash"]):
        raise HTTPException(400, "Current password is incorrect")
    if len(new) < 8:
        raise HTTPException(400, "New password must be at least 8 characters")
    store.change_password(user["id"], new)
    store.audit(None, user["id"], user["email"], "change_password", "")
    return {"ok": True}


# --------------------------------------------------------------------------
# User management (admin only)
# --------------------------------------------------------------------------
@app.get("/api/users")
def list_users(user: dict = Depends(require_role("admin"))):
    return {"users": store.list_users()}


@app.post("/api/users")
def create_user(payload: dict, user: dict = Depends(require_role("admin"))):
    role = payload.get("role", "operator")
    if role not in auth.ROLES:
        raise HTTPException(400, "Invalid role")
    try:
        uid = store.create_user(payload.get("email", ""), payload.get("password", ""),
                                payload.get("full_name", ""), role=role)
    except ValueError as e:
        raise HTTPException(400, str(e))
    store.audit(None, user["id"], user["email"], "create_user",
                f"{payload.get('email')} as {role}")
    return {"ok": True, "id": uid}


@app.patch("/api/users/{uid}")
def update_user(uid: str, payload: dict, user: dict = Depends(require_role("admin"))):
    if uid == user["id"] and payload.get("role") not in (None, "admin"):
        raise HTTPException(400, "You cannot demote your own account")
    role = payload.get("role")
    if role is not None and role not in auth.ROLES:
        raise HTTPException(400, "Invalid role")
    store.update_user(uid, role=role, is_active=payload.get("is_active"))
    store.audit(None, user["id"], user["email"], "update_user", f"{uid} role={role}")
    return {"ok": True}


# --------------------------------------------------------------------------
# Processing pipeline
# --------------------------------------------------------------------------
def _run_pipeline(data: bytes, filename: str, uploaded_by: dict,
                  stored_path: str = None, mime: str = None, size: int = None) -> dict:
    ocr_result = ocr.process_file(data, filename)
    fields = extractor.extract_fields(ocr_result)
    fields = store.apply_learned(fields)
    validation = validator.validate(fields, scripts=ocr_result["detected_scripts"])
    dedup_key = validator.duplicate_key(fields)
    dup = store.check_duplicate(dedup_key) if dedup_key else None
    if dup:
        validation["issues"].append(
            {"field": "duplicate", "severity": "warning",
             "msg": f"Possible duplicate of record {dup['id']} ({dup['filename']})"})
        validation["duplicate_of"] = dup["id"]
    doc_id = store.save_upload(filename, mime, size, stored_path, uploaded_by["id"],
                               ocr_result, fields, validation, dedup_key)
    store.audit(doc_id, uploaded_by["id"], uploaded_by["email"],
                "document_created", filename)
    return {"id": doc_id, "filename": filename,
            "ocr": {"mean_conf": ocr_result["mean_conf"],
                    "languages": ocr_result["detected_scripts"],
                    "pages": ocr_result["num_pages"],
                    "text_preview": ocr_result["full_text"][:1500]},
            "fields": fields, "validation": validation}


@app.post("/api/process")
async def process(file: UploadFile = File(...),
                  user: dict = Depends(require_role("operator"))):
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in store.ALLOWED_EXTENSIONS:
        raise HTTPException(400, f"Unsupported file type '{ext}'. "
                                 f"Allowed: {', '.join(sorted(store.ALLOWED_EXTENSIONS))}")
    data = await file.read()
    if not data:
        raise HTTPException(400, "Empty file")
    if len(data) > store.MAX_UPLOAD_BYTES:
        raise HTTPException(413, f"File exceeds {store.MAX_UPLOAD_BYTES // (1024*1024)} MB limit")
    stored_path = os.path.join(store.UPLOAD_DIR, uuid.uuid4().hex + ext)
    with open(stored_path, "wb") as fh:
        fh.write(data)
    try:
        result = _run_pipeline(data, file.filename or "upload", user,
                               stored_path=stored_path, mime=file.content_type, size=len(data))
    except Exception as e:  # noqa: BLE001
        if os.path.exists(stored_path):
            os.remove(stored_path)
        raise HTTPException(500, f"Processing failed: {e}")
    return result


@app.post("/api/process/sample/{name}")
def process_sample(name: str, user: dict = Depends(require_role("operator"))):
    path = os.path.join(SAMPLES_DIR, name)
    if not os.path.exists(path) or not os.path.isfile(path):
        raise HTTPException(404, "Sample not found")
    with open(path, "rb") as fh:
        data = fh.read()
    return _run_pipeline(data, name, user)


@app.get("/api/samples")
def list_samples(user: dict = Depends(get_current_user)):
    d = SAMPLES_DIR
    if not os.path.exists(d):
        return {"samples": []}
    return {"samples": sorted(f for f in os.listdir(d) if not f.startswith("."))}


# --------------------------------------------------------------------------
# Documents, verification, dashboards
# --------------------------------------------------------------------------
@app.get("/api/documents")
def documents(user: dict = Depends(get_current_user)):
    return {"documents": store.list_documents()}


@app.get("/api/documents/{doc_id}")
def document(doc_id: str, user: dict = Depends(get_current_user)):
    doc = store.get_document(doc_id)
    if not doc:
        raise HTTPException(404, "Not found")
    doc["fields"] = json.loads(doc["extracted_json"])
    doc["validation"] = json.loads(doc["validation_json"])
    doc.pop("ocr_text", None)
    return doc


@app.get("/api/documents/{doc_id}/file")
def document_file(doc_id: str, user: dict = Depends(get_current_user)):
    doc = store.get_document(doc_id)
    if not doc or not doc.get("stored_path") or not os.path.exists(doc["stored_path"]):
        raise HTTPException(404, "File not found")
    return FileResponse(doc["stored_path"], filename=doc["filename"])


@app.post("/api/documents/{doc_id}/verify")
def verify(doc_id: str, payload: dict, user: dict = Depends(require_role("verifier"))):
    corrections = payload.get("corrections", {})
    fields = store.mark_verified(doc_id, corrections, user)
    if fields is None:
        raise HTTPException(404, "Not found")
    return {"id": doc_id, "fields": fields, "status": "verified"}


@app.delete("/api/documents/{doc_id}")
def delete_document(doc_id: str, user: dict = Depends(require_role("admin"))):
    doc = store.get_document(doc_id)
    if not doc:
        raise HTTPException(404, "Not found")
    c = store._conn()
    c.execute("DELETE FROM documents WHERE id=?", (doc_id,))
    c.execute("DELETE FROM audit WHERE doc_id=?", (doc_id,))
    c.commit()
    c.close()
    if doc.get("stored_path") and os.path.exists(doc["stored_path"]):
        os.remove(doc["stored_path"])
    store.audit(None, user["id"], user["email"], "delete_document", doc_id)
    return {"ok": True}


@app.get("/api/dashboard")
def dashboard(user: dict = Depends(get_current_user)):
    return store.dashboard_stats()


@app.get("/api/corrections")
def corrections(user: dict = Depends(require_role("verifier"))):
    return {"corrections": store.get_learned_corrections()}


@app.get("/api/audit")
def audit_all(user: dict = Depends(require_role("verifier"))):
    return {"audit": store.get_audit()}


@app.get("/api/audit/{doc_id}")
def audit_doc(doc_id: str, user: dict = Depends(require_role("verifier"))):
    return {"audit": store.get_audit(doc_id=doc_id)}


@app.get("/api/fields")
def field_metadata(user: dict = Depends(get_current_user)):
    return {"fields": [{"id": f[0], "label": f[1]} for f in common.FIELD_DEFS],
            "verify_threshold": validator.VERIFY_THRESHOLD,
            "roles": {r: auth.ROLE_LABELS[r] for r in auth.ROLES}}


@app.get("/")
def index():
    return FileResponse(os.path.join(STATIC, "index.html"),
                        headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
                                 "Pragma": "no-cache", "Expires": "0"})


app.mount("/static", StaticFiles(directory=STATIC), name="static")
