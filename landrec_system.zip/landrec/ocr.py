"""OCR engine: image preprocessing + multilingual Tesseract OCR."""
import os
import re
import cv2
import numpy as np
import pytesseract
from PIL import Image
import fitz  # PyMuPDF for PDFs

from . import common, paths

# Locate Tesseract:
#   1. explicit PYTESSERACT_PATH env var (e.g. set by the Windows launcher)
#   2. bundled copy inside a frozen .exe (tesseract/tesseract.exe + tessdata)
#   3. system PATH (Linux/macOS default)
if os.environ.get("PYTESSERACT_PATH"):
    pytesseract.pytesseract.tesseract_cmd = os.environ["PYTESSERACT_PATH"]
elif paths.is_frozen():
    bundled = os.path.join(paths.resource_dir(), "tesseract", "tesseract.exe")
    if os.path.exists(bundled):
        pytesseract.pytesseract.tesseract_cmd = bundled
        os.environ.setdefault("TESSDATA_PREFIX",
                              os.path.join(paths.resource_dir(), "tesseract", "tessdata"))

TESSDATA_DIR = "/usr/share/tesseract-ocr/5/tessdata"


def _preprocess(gray: np.ndarray) -> np.ndarray:
    """Denoise + adaptive threshold to make faded/scanned text readable."""
    gray = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
    # adaptive threshold for uneven illumination / faded ink
    gray = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 15
    )
    return gray


def pdf_to_images(data: bytes, dpi: int = 300) -> list:
    """Convert PDF bytes to list of PIL Images (first 5 pages for demo)."""
    doc = fitz.open(stream=data, filetype="pdf")
    images = []
    for page in doc[:5]:
        pix = page.get_pixmap(dpi=dpi)
        images.append(Image.frombytes("RGB", (pix.width, pix.height), pix.samples))
    return images


def image_to_numpy(img: Image.Image) -> np.ndarray:
    arr = np.array(img.convert("RGB"))
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


def ocr_image(img: Image.Image, langs: list = None) -> dict:
    """OCR a single PIL image. Returns dict with full text and per-word conf."""
    bgr = image_to_numpy(img)
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    processed = _preprocess(gray)

    if langs is None:
        # quick script detection on a low-res pass
        try:
            quick = pytesseract.image_to_string(processed, lang="eng+hin",
                                                config="--psm 6")
        except Exception:
            quick = ""
        langs = ["hin", "eng"] if "Devanagari" in str(common.detect_scripts(quick)) or \
            common.detect_scripts(quick) else ["eng"]

    lang_str = "+".join(dict.fromkeys(langs + ["eng"]))
    cfg = "--psm 6"
    data = pytesseract.image_to_data(processed, lang=lang_str, config=cfg,
                                     output_type=pytesseract.Output.DICT)

    words, confs = [], []
    for w, c in zip(data["text"], data["conf"]):
        w = (w or "").strip()
        if w:
            words.append(w)
            confs.append(int(float(c)))

    text = pytesseract.image_to_string(processed, lang=lang_str, config=cfg)
    mean_conf = (sum(confs) / len(confs)) if confs else 0.0
    return {"text": text, "words": words, "conf": confs, "mean_conf": round(mean_conf, 1),
            "langs": langs}


def process_file(data: bytes, filename: str) -> dict:
    """Entry point: file bytes -> OCR result (handles image or PDF)."""
    name = filename.lower()
    if name.endswith(".pdf"):
        images = pdf_to_images(data)
    else:
        images = [Image.open(__import__("io").BytesIO(data)).convert("RGB")]

    pages = []
    for img in images:
        pages.append(ocr_image(img))

    full_text = "\n".join(p["text"] for p in pages)
    mean_conf = sum(p["mean_conf"] for p in pages) / len(pages) if pages else 0.0
    return {
        "pages": pages,
        "full_text": full_text,
        "mean_conf": round(mean_conf, 1),
        "num_pages": len(pages),
        "detected_scripts": common.detect_scripts(full_text),
    }
