"""Shared utilities: numeral conversion, script detection, label dictionaries."""
import re

# ---------- Numeral conversion ----------
DEVANAGARI_DIGITS = str.maketrans("०१२३४५६७८९", "0123456789")
ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")

def normalize_numerals(text: str) -> str:
    """Convert Devanagari and Arabic-Indic digits to ASCII digits."""
    if not text:
        return ""
    return text.translate(DEVANAGARI_DIGITS).translate(ARABIC_DIGITS)

def digits_only(text: str) -> str:
    """Return only ASCII digits from a string."""
    return re.sub(r"[^0-9]", "", normalize_numerals(text or ""))

# ---------- Script detection (for OCR language selection) ----------
SCRIPT_RANGES = {
    "Devanagari": ("hin", (0x0900, 0x097F)),
    "Bengali":    ("ben", (0x0980, 0x09FF)),
    "Gujarati":   ("guj", (0x0A80, 0x0AFF)),
    "Tamil":      ("tam", (0x0B80, 0x0BFF)),
    "Telugu":     ("tel", (0x0C00, 0x0C7F)),
    "Kannada":    ("kan", (0x0C80, 0x0CFF)),
    "Urdu/Arabic":("urd", (0x0600, 0x06FF)),
}

def detect_scripts(text: str) -> list:
    """Return ordered list of ISO-639-3 language codes present in text.
    A script must appear at least MIN_CHARS times to count (avoids stray glyphs)."""
    MIN_CHARS = 3
    found = []
    for name, (code, (lo, hi)) in SCRIPT_RANGES.items():
        cnt = sum(1 for ch in text if lo <= ord(ch) <= hi)
        if cnt >= MIN_CHARS:
            found.append(code)
    return found

# ---------- Field definitions & label dictionaries ----------
# Each field: id, display name, list of label synonyms (lowercased) used for matching.
FIELD_DEFS = [
    ("owner_name",      "Landowner Name", [
        "भूमि स्वामी", "मालिक का नाम", "काश्तकार", "स्वामी का नाम", "धारक का नाम",
        "land owner", "landowner", "owner name", "owner", "name of owner", "khatedar",
        "holder name", "ryot", "cultivator", "पट्टाधारक", "मालिक"]),
    ("father_name",     "Father's Name", [
        "पिता का नाम", "पिता", "father name", "father's name", "s/o", "son of",
        "वालिद का नाम", "father"]),
    ("survey_number",   "Survey Number", [
        "सर्वे नंबर", "सर्वे नं.", "सर्वे संख्या", "सर्वेक्षण संख्या", "सर्वेक्षण क्र.",
        "survey no", "survey number", "survey #", "s.no", "survey no."]),
    ("khasra_number",   "Khasra Number", [
        "खसरा नंबर", "खसरा संख्या", "खसरा क्र.", "खसरा",
        "khasra no", "khasra number", "khasra #"]),
    ("khata_number",    "Khata Number", [
        "खाता नंबर", "खाता संख्या", "खाता क्र.",
        "khata no", "khata number", "account no", "account number"]),
    ("plot_number",     "Plot Number", [
        "प्लॉट नंबर", "प्लाट नं.", "भूखंड संख्या",
        "plot no", "plot number", "plot #"]),
    ("area",            "Plot Area", [
        "क्षेत्रफल", "रकबा", "क्षेत्र", "एरिया",
        "area", "extent", "total area", "plot area", "land area"]),
    ("village",         "Village", [
        "गाँव", "गांव", "ग्राम", "ग्राम का नाम", "मौजा", "ग्राम पंचायत",
        "village", "mauza", "gram"]),
    ("tehsil",          "Tehsil / Taluka", [
        "तहसील", "तालुका", "तालुक", "मंडल",
        "tehsil", "tahsil", "taluka", "taluk", "mandal"]),
    ("district",        "District", [
        "जिला", "ज़िला", "जनपद",
        "district", "zilla"]),
    ("state",           "State", [
        "राज्य", "प्रदेश", "state"]),
    ("land_class",      "Land Classification", [
        "भूमि का प्रकार", "भूमि वर्ग", "भू-वर्ग", "वर्ग", "भूमि का वर्ग",
        "land type", "land classification", "class of land", "land class", "soil type"]),
    ("ownership_type",  "Ownership Type", [
        "स्वामित्व प्रकार", "स्वामित्व", "मालिकाना",
        "ownership type", "ownership", "tenure"]),
    ("mutation_no",     "Mutation Number", [
        "दाखिल खारिज", "म्यूटेशन नंबर", "म्यूटेशन संख्या", "इंतकाल",
        "mutation no", "mutation number", "mutation #", "dakhil kharij"]),
    ("registration_no","Registration Number", [
        "पंजीकरण संख्या", "पंजीयन क्र.", "रजिस्ट्री नंबर", "रजिस्ट्रेशन नंबर",
        "registration no", "registration number", "reg. no", "reg no"]),
    ("khatauni_year",   "Khatauni Year", [
        "खतौनी वर्ष", "फसल वर्ष", "साल",
        "khatauni year", "crop year", "year"]),
]

FIELD_IDS = [f[0] for f in FIELD_DEFS]
FIELD_LABELS = {f[0]: f[1] for f in FIELD_DEFS}

# Ordered labels per field, longest first so "survey number" beats "survey"
LABEL_PATTERNS = {}
for fid, _display, labels in FIELD_DEFS:
    LABEL_PATTERNS[fid] = sorted(labels, key=len, reverse=True)

# ---------- Land classification vocabulary (Hindi + English) ----------
LAND_CLASSES = [
    ("Irrigated",      ["सिंचित", "sichit", "irrigated", "irrigated land"]),
    ("Non-Irrigated",  ["असिंचित", "बारानी", "asinchit", "barani", "non-irrigated", "unirrigated", "rainfed"]),
    ("Agricultural",   ["कृषि", "कृषि योग्य", "agricultural", "cultivable", "arable"]),
    ("Barren",         ["बंजर", "बन्जर", "banjar", "barren", "wasteland", "uncultivable"]),
    ("Residential",    ["आवासीय", "गैर-मुकिन", "residential", "abadi", "आबादी"]),
    ("Pasture",        ["चरागाह", "गोचर", "charagah", "gochar", "pasture", "grazing"]),
    ("Forest",         ["वन", "जंगल", "forest", "jungle"]),
]

OWNERSHIP_TYPES = [
    ("Private",       ["निजी", "private", "personal"]),
    ("Government",    ["सरकारी", "राजकीय", "government", "govt", "state"]),
    ("Joint/Co-owned",["संयुक्त", "joint", "co-owned", "shared", "संयुक्त स्वामित्व"]),
    ("Tenant/Cultivator", ["काश्तकार", "tenant", "cultivator", "गैर-खातेदार"]),
]

# ---------- Area units ----------
AREA_UNITS = {
    "hectare": ["हेक्टेयर", "हेक्टर", "hectare", "ha", "hect"],
    "acre":    ["एकड़", "एकड", "acre", "ac", "acres"],
    "bigha":   ["बीघा", "bigha", "bigha"],
    "sq_ft":   ["वर्ग फुट", "वर्ग फीट", "square feet", "sq ft", "sqft", "sq. ft", "sft"],
    "sq_m":    ["वर्ग मीटर", "square meter", "sq m", "sqm", "sq. m", "sqmt"],
    "gunta":   ["गुंठा", "गुंठे", "gunta", "gunta"],
}
