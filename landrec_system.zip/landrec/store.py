"""Persistence: SQLite store for users, documents, audit trail, learned corrections."""
import json
import os
import sqlite3
import time
import uuid

from . import auth, common, paths

DATA_DIR = os.path.join(paths.data_dir(), "data")
DB_PATH = os.path.join(DATA_DIR, "landrec.db")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")

ALLOWED_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png", ".tif", ".tiff"}
MAX_UPLOAD_BYTES = 20 * 1024 * 1024  # 20 MB

# Roles allowed to perform actions (checked server-side)
UPLOAD_ROLES = {"operator", "verifier", "admin"}
VERIFY_ROLES = {"verifier", "admin"}
ADMIN_ROLES = {"admin"}


def _conn():
    os.makedirs(DATA_DIR, exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    c = _conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        salt TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'operator',
        token_version INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at REAL
    );
    CREATE TABLE IF NOT EXISTS documents (
        id TEXT PRIMARY KEY,
        filename TEXT,
        stored_path TEXT,
        mime_type TEXT,
        file_size INTEGER,
        uploaded_by TEXT,
        uploaded_at REAL,
        ocr_text TEXT,
        mean_conf REAL,
        languages TEXT,
        extracted_json TEXT,
        validation_json TEXT,
        verdict TEXT,
        status TEXT,
        dedup_key TEXT
    );
    CREATE TABLE IF NOT EXISTS audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        doc_id TEXT,
        ts REAL,
        user_id TEXT,
        username TEXT,
        action TEXT,
        detail TEXT
    );
    CREATE TABLE IF NOT EXISTS corrections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        field_id TEXT,
        wrong TEXT,
        right TEXT,
        count INTEGER DEFAULT 1,
        UNIQUE(field_id, wrong, right)
    );
    CREATE TABLE IF NOT EXISTS login_attempts (
        email TEXT PRIMARY KEY,
        failures INTEGER DEFAULT 0,
        locked_until REAL DEFAULT 0
    );
    """)
    c.commit()
    c.close()
    _seed_admin(c=None)


def _seed_admin(c=None):
    """Create a default administrator account on first run."""
    c = c or _conn()
    row = c.execute("SELECT COUNT(*) n FROM users").fetchone()
    if row["n"] == 0:
        salt, pwh = auth.hash_password("Admin@123")
        c.execute("INSERT INTO users (id, email, password_hash, salt, full_name, role, created_at)"
                  " VALUES (?,?,?,?,?,?,?)",
                  (uuid.uuid4().hex[:12], "admin@landrec.gov.in", pwh, salt,
                   "System Administrator", "admin", time.time()))
        c.commit()
    c.close()


# ---------- Users ----------
def create_user(email, password, full_name, role="operator"):
    email = email.strip().lower()
    if not email or "@" not in email:
        raise ValueError("Invalid email address")
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters")
    if role not in auth.ROLES:
        raise ValueError("Invalid role")
    salt, pwh = auth.hash_password(password)
    uid = uuid.uuid4().hex[:12]
    c = _conn()
    try:
        c.execute("INSERT INTO users (id, email, password_hash, salt, full_name, role, created_at)"
                  " VALUES (?,?,?,?,?,?,?)",
                  (uid, email, pwh, salt, full_name.strip() or "User", role, time.time()))
        c.commit()
    except sqlite3.IntegrityError:
        c.close()
        raise ValueError("An account with this email already exists")
    c.close()
    return uid


def get_user(uid):
    c = _conn()
    row = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    c.close()
    return dict(row) if row else None


def get_user_by_email(email):
    c = _conn()
    row = c.execute("SELECT * FROM users WHERE email=?", (email.strip().lower(),)).fetchone()
    c.close()
    return dict(row) if row else None


def list_users():
    c = _conn()
    rows = c.execute("SELECT id, email, full_name, role, is_active, created_at FROM users "
                     "ORDER BY created_at").fetchall()
    c.close()
    return [dict(r) for r in rows]


def update_user(uid, role=None, is_active=None):
    c = _conn()
    if role is not None:
        c.execute("UPDATE users SET role=? WHERE id=?", (role, uid))
    if is_active is not None:
        c.execute("UPDATE users SET is_active=? WHERE id=?", (1 if is_active else 0, uid))
    c.commit()
    c.close()


def change_password(uid, new_password):
    """Set a new password and invalidate all existing sessions."""
    salt, pwh = auth.hash_password(new_password)
    c = _conn()
    c.execute("UPDATE users SET password_hash=?, salt=?, token_version=token_version+1 "
              "WHERE id=?", (pwh, salt, uid))
    c.commit()
    c.close()


def bump_token_version(uid):
    c = _conn()
    c.execute("UPDATE users SET token_version=token_version+1 WHERE id=?", (uid,))
    c.commit()
    c.close()


def record_login_failure(email):
    c = _conn()
    c.execute("INSERT INTO login_attempts (email, failures, locked_until) VALUES (?,1,0) "
              "ON CONFLICT(email) DO UPDATE SET failures = failures + 1", (email,))
    row = c.execute("SELECT failures FROM login_attempts WHERE email=?", (email,)).fetchone()
    if row and row["failures"] >= 5:
        c.execute("UPDATE login_attempts SET locked_until=? WHERE email=?",
                  (time.time() + 300, email))  # 5 min lock
    c.commit()
    c.close()


def login_locked(email):
    c = _conn()
    row = c.execute("SELECT locked_until, failures FROM login_attempts WHERE email=?",
                    (email,)).fetchone()
    c.close()
    if row and row["locked_until"] > time.time():
        return True
    return False


def clear_login_failures(email):
    c = _conn()
    c.execute("DELETE FROM login_attempts WHERE email=?", (email,))
    c.commit()
    c.close()


# ---------- Audit ----------
def audit(doc_id, user_id, username, action, detail=""):
    c = _conn()
    c.execute("INSERT INTO audit (doc_id, ts, user_id, username, action, detail) "
              "VALUES (?,?,?,?,?,?)",
              (doc_id, time.time(), user_id, username, action, detail))
    c.commit()
    c.close()


# ---------- Documents ----------
def save_upload(filename, mime, size, stored_path, uploaded_by, ocr_result, fields,
                validation, dedup_key):
    doc_id = uuid.uuid4().hex[:12]
    status = "pending_review" if validation["low_confidence_fields"] else (
        "auto_approved" if validation["verdict"] == "valid" else "pending_review")
    c = _conn()
    c.execute("""INSERT INTO documents
        (id, filename, stored_path, mime_type, file_size, uploaded_by, uploaded_at,
         ocr_text, mean_conf, languages, extracted_json, validation_json, verdict,
         status, dedup_key)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (doc_id, filename, stored_path, mime, size, uploaded_by, time.time(),
         ocr_result["full_text"], ocr_result["mean_conf"],
         json.dumps(ocr_result["detected_scripts"]), json.dumps(fields),
         json.dumps(validation), validation["verdict"], status, dedup_key))
    c.commit()
    c.close()
    return doc_id


def get_document(doc_id):
    c = _conn()
    row = c.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
    c.close()
    return dict(row) if row else None


def list_documents(limit=500):
    c = _conn()
    rows = c.execute(
        "SELECT id, filename, uploaded_by, uploaded_at, mean_conf, verdict, status, "
        "extracted_json FROM documents ORDER BY uploaded_at DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    out = []
    for r in rows:
        d = dict(r)
        d["fields"] = json.loads(d.pop("extracted_json"))
        out.append(d)
    return out


def check_duplicate(dedup_key):
    c = _conn()
    row = c.execute("SELECT id, filename FROM documents WHERE dedup_key=? AND dedup_key!=''",
                    (dedup_key,)).fetchone()
    c.close()
    return dict(row) if row else None


def mark_verified(doc_id, corrections, user):
    doc = get_document(doc_id)
    if not doc:
        return None
    fields = json.loads(doc["extracted_json"])
    c = _conn()
    ts = time.time()
    audit_rows = []
    for fid, newval in (corrections or {}).items():
        old = fields.get(fid, {}).get("value", "") if fid in fields else ""
        newval = (newval or "").strip()
        if fid in fields:
            fields[fid]["value"] = newval
            fields[fid]["confidence"] = 1.0
            fields[fid]["verified"] = True
        else:
            fields[fid] = {"value": newval, "confidence": 1.0, "verified": True}
        if newval != old and old:
            c.execute("""INSERT INTO corrections (field_id, wrong, right, count)
                         VALUES (?,?,?,1)
                         ON CONFLICT(field_id, wrong, right)
                         DO UPDATE SET count = count + 1""", (fid, old, newval))
            audit_rows.append((doc_id, ts, user["id"], user["email"], "correction",
                               f"{fid}: '{old}' -> '{newval}'"))
    c.execute("UPDATE documents SET extracted_json=?, status='verified', verdict='verified' "
              "WHERE id=?", (json.dumps(fields), doc_id))
    audit_rows.append((doc_id, ts, user["id"], user["email"], "verified",
                       f"{len(corrections or {})} fields confirmed"))
    c.executemany("INSERT INTO audit (doc_id, ts, user_id, username, action, detail) "
                  "VALUES (?,?,?,?,?,?)", audit_rows)
    c.commit()
    c.close()
    return fields


def get_learned_corrections(field_id=None):
    c = _conn()
    if field_id:
        rows = c.execute("SELECT wrong, right, count FROM corrections WHERE field_id=? "
                         "ORDER BY count DESC LIMIT 50", (field_id,)).fetchall()
    else:
        rows = c.execute("SELECT field_id, wrong, right, count FROM corrections "
                         "ORDER BY count DESC LIMIT 100").fetchall()
    c.close()
    return [dict(r) for r in rows]


def apply_learned(fields):
    c = _conn()
    rows = c.execute("SELECT field_id, wrong, right FROM corrections ORDER BY count DESC").fetchall()
    c.close()
    for r in rows:
        fid = r["field_id"]
        if fid in fields:
            val = fields[fid].get("value", "")
            if val and r["wrong"] and r["wrong"].lower() in val.lower():
                fields[fid]["value"] = val.replace(r["wrong"], r["right"])
                fields[fid]["auto_corrected"] = True
    return fields


def get_audit(doc_id=None, limit=500):
    c = _conn()
    if doc_id:
        rows = c.execute("SELECT ts, user_id, username, action, detail FROM audit "
                         "WHERE doc_id=? ORDER BY ts", (doc_id,)).fetchall()
    else:
        rows = c.execute("SELECT doc_id, ts, user_id, username, action, detail FROM audit "
                         "ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]


def dashboard_stats():
    c = _conn()
    total = c.execute("SELECT COUNT(*) n FROM documents").fetchone()["n"]
    verified = c.execute("SELECT COUNT(*) n FROM documents WHERE status='verified'").fetchone()["n"]
    pending = c.execute("SELECT COUNT(*) n FROM documents WHERE status='pending_review'").fetchone()["n"]
    auto = c.execute("SELECT COUNT(*) n FROM documents WHERE status='auto_approved'").fetchone()["n"]
    rejected = c.execute("SELECT COUNT(*) n FROM documents WHERE verdict='rejected'").fetchone()["n"]
    avg_conf = c.execute("SELECT AVG(mean_conf) a FROM documents").fetchone()["a"] or 0
    users = c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
    rows = c.execute("SELECT extracted_json FROM documents").fetchall()
    c.close()
    states, districts = {}, {}
    for r in rows:
        f = json.loads(r["extracted_json"])
        st = f.get("state", {}).get("value")
        dt = f.get("district", {}).get("value")
        if st:
            states[st] = states.get(st, 0) + 1
        if dt:
            districts[dt] = districts.get(dt, 0) + 1
    return {
        "total": total, "verified": verified, "pending_review": pending,
        "auto_approved": auto, "rejected": rejected, "users": users,
        "avg_ocr_confidence": round(avg_conf, 1),
        "accuracy_estimate": round(verified / total * 100, 1) if total else 0,
        "by_state": dict(sorted(states.items(), key=lambda x: -x[1])[:10]),
        "by_district": dict(sorted(districts.items(), key=lambda x: -x[1])[:10]),
    }
