@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Build LandRecordSystem.exe
cd /d "%~dp0"

echo ============================================================
echo   Build LandRecordSystem.exe  (single-file, one-time build)
echo ============================================================
echo.

REM ---- 1. Python check ----
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.9+ is required to BUILD the exe.
    echo         Install from https://www.python.org/downloads/
    echo         IMPORTANT: tick "Add Python to PATH".
    pause
    exit /b 1
)
REM Verify Python is 3.9+ (robust exit-code check, no fragile text parsing)
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python 3.9 or newer is required to build the executable.
    for /f "tokens=1" %%v in ('python -c "import sys;print(sys.version.split()[0])" 2^>nul') do echo         Detected Python: %%v
    echo         Install from https://www.python.org/downloads/
    echo         IMPORTANT: tick "Add Python to PATH" during install.
    pause
    exit /b 1
)

REM ---- 2. Virtual environment + dependencies ----
echo [1/4] Setting up build environment...
if not exist "buildenv" (
    python -m venv buildenv
    if errorlevel 1 (
        echo [ERROR] Could not create virtual environment.
        pause & exit /b 1
    )
)
call buildenv\Scripts\activate.bat
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt pyinstaller
if errorlevel 1 (
    echo [ERROR] Dependency install failed. Check your internet connection.
    pause & exit /b 1
)

REM ---- 3. Tesseract (required at build time so it can be bundled) ----
echo [2/4] Checking Tesseract OCR...
set "TESSDIR="
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSDIR=C:\Program Files\Tesseract-OCR"
if exist "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe" set "TESSDIR=C:\Program Files (x86)\Tesseract-OCR"
if not defined TESSDIR (
    echo       Tesseract not found - downloading the installer...
    powershell -NoProfile -Command "$r = Invoke-RestMethod 'https://api.github.com/repos/UB-Mannheim/tesseract/releases/latest'; $a = $r.assets | Where-Object { $_.name -match 'w64-setup.*\.exe$' } | Select-Object -First 1; if (-not $a) { $a = $r.assets | Where-Object { $_.name -match 'setup.*\.exe$' } | Select-Object -First 1 }; Invoke-WebRequest $a.browser_download_url -OutFile 'tesseract_setup.exe'"
    if exist "tesseract_setup.exe" (
        echo       Installing Tesseract silently...
        tesseract_setup.exe /SILENT
        timeout /t 20 /nobreak >nul
        del tesseract_setup.exe
        if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSDIR=C:\Program Files\Tesseract-OCR"
        if exist "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe" set "TESSDIR=C:\Program Files (x86)\Tesseract-OCR"
    )
)
if not defined TESSDIR (
    echo [ERROR] Tesseract OCR could not be installed automatically.
    echo         Install it manually from: https://github.com/UB-Mannheim/tesseract/wiki
    echo         then re-run this script.
    pause
    exit /b 1
)
echo       Using Tesseract at: !TESSDIR!

REM ---- 4. Build the single-file exe ----
echo [3/4] Building single-file executable (this takes a few minutes)...
python -m PyInstaller --noconfirm --clean --onefile --name LandRecordSystem ^
    --add-data "landrec/static;landrec/static" ^
    --add-data "samples;samples" ^
    --add-data "!TESSDIR!;tesseract" ^
    --hidden-import "uvicorn.logging" ^
    --hidden-import "uvicorn.loops" ^
    --hidden-import "uvicorn.loops.auto" ^
    --hidden-import "uvicorn.protocols" ^
    --hidden-import "uvicorn.protocols.http" ^
    --hidden-import "uvicorn.protocols.http.auto" ^
    --hidden-import "uvicorn.protocols.websockets" ^
    --hidden-import "uvicorn.protocols.websockets.auto" ^
    --hidden-import "uvicorn.lifespan" ^
    --hidden-import "uvicorn.lifespan.on" ^
    --hidden-import "fitz" ^
    --hidden-import "pymupdf" ^
    --collect-submodules "pymupdf" ^
    run.py
if errorlevel 1 (
    echo [ERROR] Build failed. See the messages above.
    pause
    exit /b 1
)

REM ---- 5. Done ----
echo [4/4] Done!
echo.
echo   SUCCESS: dist\LandRecordSystem.exe  has been created.
echo.
echo   Copy that single file to any Windows PC and double-click it.
echo   No Python or Tesseract installation needed on the target machine.
echo.
pause
